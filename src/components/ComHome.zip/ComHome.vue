<template>
  <div class="common-layout">
    <el-container>
      <!-- 头部 -->
      <el-header>
        <div class="add">
          <el-button :plain="true" @click="handleAdd">新增数据</el-button>
        </div>

        <div class="title">后台管理系统</div>
        <span id="logout">
          <router-link to="/"
            ><el-button :plain="true" @click="open2"
              >退出</el-button
            ></router-link
          ></span
        >
      </el-header>
      <hr />
      <!-- 主体 -->
      <el-main
        ><el-table :data="filterTableData" style="width: 100%">
          <el-table-column class="one" label="id" prop="id" />
          <el-table-column label="用户名" prop="name" />
          <el-table-column label="性别" prop="sex" />
          <el-table-column label="年龄" prop="age" />
          <el-table-column label="爱好" prop="hobby" />
          <el-table-column>
            <template #header>
              <el-input
              class="search"
                v-model="search"
                size="small"
                placeholder="Type id or name "
              />
            </template>

            <template #default="scope">
              <!-- 修改按钮 -->
              <!-- scope.$index, scope.row拿到每一行的index和数据 -->
              <el-button
                size="small"
                @click="handleEdit(scope.row, scope.$index)"
                >Edit</el-button
              >
              <!-- 删除按钮 -->
              <el-button
                size="small"
                type="danger"
                @click="handleDelete(scope.$index)"
                >Delete</el-button
              >
            </template>
          </el-table-column>
        </el-table></el-main
      >
      <!-- 尾部 -->
      <el-footer>
        <div class="demo-pagination-block">
          <el-pagination
            v-model:current-page="currentPage4"
            v-model:page-size="pageSize4"
            :page-sizes="[5, 10, 15, 20]"
            :small="small"
            :disabled="disabled"
            :background="background"
            layout="total, sizes, prev, pager, next, jumper"
            :total="tableData.length"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
          />
        </div>
      </el-footer>
      <!-- 编辑弹窗 -->
      <el-dialog v-model="dialogFormVisible" :title="titleMsg" width="40%" round-button=true>
        <el-form :model="form" label-width="100px" style="padding-right: 30px">
          <el-form-item label="id：">
            <el-input v-model.number="form.id"></el-input>
          </el-form-item>
          <el-form-item label="姓名：">
            <el-input v-model="form.name"></el-input>
          </el-form-item>
          <el-form-item label="性别：">
            <el-input v-model="form.sex"></el-input>
          </el-form-item>
          <!-- 限制只能输入数字 -->
          <el-form-item label="年龄：">
            <el-input v-model.number="form.age"></el-input>
          </el-form-item>
          <el-form-item label="爱好：">
            <el-input v-model="form.hobby"></el-input>
          </el-form-item>
        </el-form>
        <template #footer>
          <span class="dialog-footer">
            <el-button @click="dialogFormVisible = false">取消</el-button>
            <el-button type="primary" @click="save">确认</el-button>
          </span>
        </template>
      </el-dialog>
      
    </el-container>
  </div>
</template>
<script setup>
import { ref, computed, reactive } from "vue";
const search = ref("");
const titleMsg=ref("")
let dialogFormVisible = ref(false);
let form = reactive({});
//全局保存编辑的行号
// 在某些情况下，-1可以表示默认或无效值，也可以作为索引的起始值。这样的设置通常是为了在后续的逻辑中判断globalIndex的有效性
const globalIndex = ref(-1);

const tableData = ref([
  {
    id: "22280419",
    name: "flavia",
    sex: "女",
    age: "19",
    hobby: "吃饭",
  },
  {
    id: "22280420",
    name: "abcflavia",
    sex: "女",
    age: "19",
    hobby: "吃饭",
  },
  {
    id: "22280421",
    name: "abcflavia",
    sex: "女",
    age: "18",
    hobby: "吃饭",
  },
  {
    id: "22280422",
    name: "flavia",
    sex: "女",
    age: "19",
    hobby: "吃饭",
  },
  {
    id: "22280423",
    name: "abcflavia",
    sex: "女",
    age: "20",
    hobby: "吃饭",
  },
  {
    id: "22280424",
    name: "flavia",
    sex: "女",
    age: "19",
    hobby: "play",
  },
]);
//新增数据 设置新的空的绑值对象 打开弹窗
const handleAdd = () => {
  form = reactive({});
  //打开弹窗
  titleMsg.value='新增信息'
  dialogFormVisible.value = true;
};
//保存数据，把数据插入到tableData中，并刷新页面，弹窗关闭
const save = () => {
  if (globalIndex.value >= 0) {
    //表示编辑
    tableData.value[globalIndex.value] = form;
    //还原回去
    globalIndex.value = -1;
  } else {
    //新增
    tableData.value.push(form);
  }

  dialogFormVisible.value = false;
};
//编辑
const handleEdit = (row, index) => {
  const newObj = Object.assign({}, row);
  form = reactive(newObj);
  //把当前编辑的行号赋值给全局保存的行号
  globalIndex.value = index;
  console.log(globalIndex.value);
  dialogFormVisible.value = true;
  titleMsg.value='编辑信息'
};

const handleDelete = (index) => {
  tableData.value.splice(index, 1);
};
const filterTableData = computed(() =>
  tableData.value.filter(
    (data) =>
      !search.value ||
      data.name.toLowerCase().includes(search.value.toLowerCase()) ||
      data.id.toLowerCase().includes(search.value.toLowerCase())
  )
);
const pageCount = computed(() =>
  Math.ceil(tableData.value.length / pageSize4.value)
);
//尾部

const currentPage4 = ref(1);
const pageSize4 = ref(10);

// 处理每页显示条数改变事件
function handleSizeChange(size) {
  pageSize4.value = size;
  currentPage4.value = 1; // 重置当前页码为第一页
}

// 处理当前页码改变事件
function handleCurrentChange(page) {
  currentPage4.value = page;
}
//退出通知弹窗
const open2 = () => {
  ElMessage({
    message: "成功退出.",
    type: "success",
  });
};
</script>
<!-- 样式 -->
<style scoped>
.el-footer,
.el-header {
  /* background-color: rgba(220, 206, 233, 0.432); */
  line-height: 60px;
  margin: 0 auto;
}

.el-main {
  padding-left: 0 120px;
}

.el-header {
  display: flex;
}
.title {
  font-size: 22px;
  font-weight: 600;
  margin: 0 auto;
}

/* .td{
    background-color: rgba(220, 206, 233, 0.432);
} */

hr {
  width: 100%;
}
.search {
  width: 115px;
  height: 24px;
}
#logout {
  display: block;
  position: absolute;
  right: 50px;
}
.add {
  display: block;
  position: absolute;
  left: 50px;
}
.el-table,
.cell {
  padding: 0 25px;
}
.search{
  width: 115px;
  font-size: 12px;
}
.el-dialog{
  border-radius: 150px;
}
</style>